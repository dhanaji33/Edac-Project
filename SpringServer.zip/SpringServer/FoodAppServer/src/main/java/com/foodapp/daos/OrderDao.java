package com.foodapp.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foodapp.pojos.Order;

public interface OrderDao extends JpaRepository<Order, Integer> {

	List<Order> findByUserId(int id);
	List<Order> findById(int id);
	List<Order> findAll();
	
}
