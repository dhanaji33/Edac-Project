package com.foodapp.pojos;

import java.util.Date;
import java.util.List;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name="orders")
public class Order {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "o_id")
	@Id
	private int id;
	@Column(name = "u_id")
	private int userId;
	@Column(name = "d_address")
	private String dAddress;
	@Column(name = "phone_no")
	private String phone;
	@Column(name = "total_amount")
	private double totalAmount;
	@Column(name = "payment_type")
	private String paymentType;
	private String status;
	private String comment;
	@Column(name = "timestamp", insertable = false, updatable = false)
	private Date timeStamp;
//	@OneToMany(mappedBy = "orders", cascade = CascadeType.ALL)
//	private List<Item> itemList;
	
	
	
	@Override
	public String toString() {
		return "Order [id=" + id + ", userId=" + userId + ", dAddress=" + dAddress + ", phone=" + phone
				+ ", totalAmount=" + totalAmount + ", paymentType=" + paymentType + ", status=" + status + ", comment="
				+ comment + ", timeStamp=" + timeStamp +  "]";
	}
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(int id, int userId, String dAddress, String phone, double totalAmount, String paymentType,
			String status, String comment, Date timeStamp, List<Item> itemList) {
		super();
		this.id = id;
		this.userId = userId;
		this.dAddress = dAddress;
		this.phone = phone;
		this.totalAmount = totalAmount;
		this.paymentType = paymentType;
		this.status = status;
		this.comment = comment;
		this.timeStamp = timeStamp;
		
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getdAddress() {
		return dAddress;
	}
	public void setdAddress(String dAddress) {
		this.dAddress = dAddress;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
	
	
	
	
}
