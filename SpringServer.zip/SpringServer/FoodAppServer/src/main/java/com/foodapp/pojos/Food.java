package com.foodapp.pojos;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



@Entity
@Table(name="foods")
public class Food {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "f_id")
	@Id
	private int id;
	@Column(name = "food_name")
	private String foodName;
	private double price;

	private String image;
	private String type;
	private String description;
	@Column(name = "timestamp", insertable = false, updatable = false)
	private Date timeStamp ;
	
	
	@ManyToOne
	@JoinColumn(name="cat_id")
	private Category category ;
	
	
	
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "Food [id=" + id + ", FoodName=" + foodName + ", price=" + price + ",  type=" + type
				+ ", description=" + description + ", timeStamp=" + timeStamp + "]";
	}
	public Food() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Food(int id, String foodName, double price, int catId, String type, boolean available, String description,
			Date timeStamp, Category category,String image) {
		super();
		this.id = id;
		this.foodName = foodName;
		this.price = price;
//		this.catId = catId;
		this.type = type;
		this.description = description;
		this.timeStamp = timeStamp;
		this.image = image;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
//	public int getCatId() {
//		return catId;
//	}
//	public void setCatId(int catId) {
//		this.catId = catId;
//	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
	
	
	
	
	
}
