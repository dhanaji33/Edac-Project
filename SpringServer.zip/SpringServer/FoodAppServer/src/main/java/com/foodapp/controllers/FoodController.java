package com.foodapp.controllers;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.foodapp.DTOs.CategoryDto;
import com.foodapp.DTOs.FoodDto;
import com.foodapp.daos.CategoryDao;
import com.foodapp.daos.FoodDao;
import com.foodapp.models.Response;
import com.foodapp.pojos.Category;
import com.foodapp.pojos.Food;
import com.foodapp.services.FoodService;
import com.foodapp.utils.DiskStorageServiceImpl;

@CrossOrigin
@RequestMapping("/food")
@RestController
public class FoodController {
	@Autowired
	private FoodService foodService;
	@Autowired
	private FoodDao foodDao;
	@Autowired
	private CategoryDao cat;
	@Autowired
	private DiskStorageServiceImpl fileHandler;
	
	@GetMapping("")
	public ResponseEntity<?> findAllFood(){
		List<Food> list = foodService.findFoodAll();
		Stream<FoodDto> result = list.stream().map(Food -> FoodDto.fromEntity(Food));
		return Response.success(result);	
	}
	
//	@GetMapping("/category/{CatId}")
//	public ResponseEntity<?> FoodByCatId(@PathVariable("CatId") int id){
//		List<Food> list = foodService.findByCatId(id);
//		return Response.success(list);
//	}
//	
	
	@GetMapping("/category")
	public ResponseEntity<?> findAllCategories(){
		List<Category> list = cat.findAll();
		Stream<CategoryDto> result = list.stream().map(Category -> CategoryDto.fromEntity(Category));
		
		return Response.success(result);
	}
	@GetMapping("/category/{id}")
	public ResponseEntity<?> findCategoriesbyId(@PathVariable("id") int id){
		Category c = cat.findById(id);
		CategoryDto result =CategoryDto.fromEntity(c);
		return Response.success(result);
	}
	
	
	@GetMapping("/{id}")
	public ResponseEntity<?> findFoodById(@PathVariable("id") int id){
		Food food = foodService.findById(id);
		FoodDto result = FoodDto.fromEntity(food);
		return Response.success(result);
	}
	
	@GetMapping("/search/{name}")
	public ResponseEntity<?> FindByName(@PathVariable("name") String name){
		 List<Food> list = foodService.findByFoodNameContaining(name);
		 Stream<FoodDto> result = list.stream().map(Food -> FoodDto.fromEntity(Food));
		return Response.success(result);
	}
	
	@PostMapping("/addfood")
	public ResponseEntity<?> addFood(Food food,@RequestParam("imagefile") MultipartFile imagefile)
	{
		String fileName = fileHandler.store(imagefile);
		food.setImage(fileName);
		Food savedfood = foodService.addFood(food);
		FoodDto result = FoodDto.fromEntity(savedfood);
		return Response.success(result);
	}
	
	
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> DeleteFoodById(@PathVariable("id") int id) 
	{
		Food food = foodService.findById(id);
		if(food!= null) {
			foodDao.delete(food);
			return Response.message("success");
		}
		return Response.status(HttpStatus.NOT_FOUND);
	}
	
	
	
	
	
	@PutMapping("/update/{id}")
	public ResponseEntity<?> UpdateFoodById(@PathVariable("id") int id, Food newFood) 
	{
			Food oldfood = foodService.findById(id);
			if(oldfood!= null) {
				foodDao.save(newFood);
				return Response.message("success");
			}
		return Response.status(HttpStatus.NOT_FOUND);
	}
	
//	@PutMapping("/update/{id}")
//	public ResponseEntity<?> UpdateFoodById(@PathVariable("id") int id, Food newFood,@RequestParam("imagefile") MultipartFile imagefile) 
//	{
//		if(imagefile != null) {
//			String fileName = fileHandler.store(imagefile);
//			newFood.setImage(fileName);
//			Food oldfood1 = foodService.findById(id);
//			if(oldfood1!= null) {
//				foodDao.save(newFood);
//				return Response.message("success");
//			
//			
//		}else {
//			Food oldfood = foodService.findById(id);
//			if(oldfood!= null) {
//				foodDao.save(newFood);
//				return Response.message("success");
//			}
//		}
//		}
//		return Response.status(HttpStatus.NOT_FOUND);
//	}
	
	
	
}
