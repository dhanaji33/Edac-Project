package com.foodapp.services;

import java.util.List;

import com.foodapp.pojos.User;

public interface UserService {
	User findByEmail(String email);
	User findById(int id);
	List<User> findAll();
	User authenticate(String email,String password);
	
}
