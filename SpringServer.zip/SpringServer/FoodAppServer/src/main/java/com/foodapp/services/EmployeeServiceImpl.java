package com.foodapp.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foodapp.daos.EmployeeDao;
import com.foodapp.pojos.Employee;

@Transactional
@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao;
	
	@Override
	public Employee findByEmail(String email) {
		
		return dao.findByEmail(email);
	}

	
	@Override
	public List<Employee> findAll() {
		return dao.findAll();
	}

	


	@Override
	public Employee findById(int id) {
		return dao.findById(id);
	}


	@Override
	public Employee authenticate(String email, String password) {
		Employee emp = dao.findByEmail(email);
		if(emp!= null && emp.getPassword().equals(password)) {
			return emp;
		}
		return null;
	}

}
