package com.foodapp.DTOs;

import java.util.Date;

import org.springframework.beans.BeanUtils;

import com.foodapp.pojos.Food;


public class FoodDto {
	private int id;
	private String foodName;
	private double price;
	private String image;
	private String type;
	private String description;
	private Date timeStamp ;
	private String catName;
	private int catId;
	
	public FoodDto(int id, String foodName, double price, String image, String type, String description, Date timeStamp,
			String catName, int catId) {
		super();
		this.id = id;
		this.foodName = foodName;
		this.price = price;
		this.image = image;
		this.type = type;
		this.description = description;
		this.timeStamp = timeStamp;
		this.catName = catName;
		this.catId = catId;
	}
	
	public static FoodDto fromEntity(Food entity) {
		FoodDto dto = new FoodDto();
		BeanUtils.copyProperties(entity, dto);
		dto.setCatName(entity.getCategory().getCategoryName());
		dto.setCatId(entity.getCategory().getId());
		return dto;	
	}
	
	
	
	
	
	

	public FoodDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}
	
	
}
