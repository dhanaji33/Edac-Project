package com.foodapp.daos;



import org.springframework.data.jpa.repository.JpaRepository;

import com.foodapp.pojos.Employee;

public interface EmployeeDao extends JpaRepository<Employee, Integer> {

	Employee findByEmail(String email);
	Employee findById(int id);
}
