package com.foodapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foodapp.models.Credentials;
import com.foodapp.models.Response;
import com.foodapp.pojos.Employee;
import com.foodapp.pojos.User;
import com.foodapp.services.EmployeeService;
import com.foodapp.services.UserService;

@CrossOrigin
@RestController 	
public class LoginController {
	
	@Autowired
	private EmployeeService empService;
	@Autowired
	private UserService userService;
	
	
	
	@PostMapping("user/auth")
	public ResponseEntity<?> UserLogin(Credentials cred)
	{
		User user = userService.authenticate(cred.getEmail(), cred.getPassword());
		System.out.println(user);
		if(user!= null)
			return Response.success(user);
		
		return Response.message("Sorry ! email or passowrd is wrong");
	}
	
	
	@PostMapping("emp/auth")
	public ResponseEntity<?> AdminLogin(Credentials cred)
	{
		Employee emp = empService.authenticate(cred.getEmail(), cred.getPassword());
	
		if(emp!= null)
			return Response.success(emp);
		return Response.message("Sorry ! email or passowrd is wrong");
	}
	
	
	
	
	
	
}
