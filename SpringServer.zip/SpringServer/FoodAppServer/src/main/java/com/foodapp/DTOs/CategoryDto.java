package com.foodapp.DTOs;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.BeanUtils;

import com.foodapp.pojos.Category;
import com.foodapp.pojos.Food;

public class CategoryDto {
	
	private int id;
	private String categoryName;
	private Date timeStamp;
	
	private List<FoodDto> foodList;
	
	

	public CategoryDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CategoryDto(int id, String categoryName, Date timeStamp, List<FoodDto> foodList) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.timeStamp = timeStamp;
		this.foodList = foodList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public Date getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}

	public List<FoodDto> getFoodList() {
		return foodList;
	}

	public void setFoodList(List<FoodDto> foodList) {
		this.foodList = foodList;
	}
	
	public static CategoryDto fromEntity(Category entity ) {
		CategoryDto dto = new CategoryDto();
		BeanUtils.copyProperties(entity, dto);
		List<Food> list= entity.getFoodlist();
		Stream<FoodDto> r = list.stream().map(Food -> FoodDto.fromEntity(Food));
		List<FoodDto> result = r.collect(Collectors.toList());
		dto.setFoodList(result);
		return dto;
		
	}

	
	

}
