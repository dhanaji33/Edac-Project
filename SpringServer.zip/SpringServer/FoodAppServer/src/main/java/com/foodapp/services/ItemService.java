package com.foodapp.services;

import java.util.List;

import com.foodapp.pojos.Item;

public interface ItemService{
	List<Item> findByOrderId(int id);
	List<Item> findAll();
}
