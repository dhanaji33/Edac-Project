package com.foodapp.services;

import java.util.List;

import com.foodapp.pojos.Employee;


public interface EmployeeService {

	Employee findByEmail(String email);
	Employee findById(int id);
	List<Employee> findAll();
	Employee authenticate(String email,String password);
	
	
}
