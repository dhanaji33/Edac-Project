package com.foodapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodAppServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodAppServerApplication.class, args);
	}

}
