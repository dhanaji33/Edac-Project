package com.foodapp.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="items")
public class Item {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private int id;
	@Column(name = "o_id")
	private int orderId;
	@Column(name = "f_id")
	private int foodId;
	@Column(name = "food_name")
	private String foodName;
	@Column(name = "unit_price")
	private double price;
	@Column(name = "unit_quantity")
	private int unitQuanity;
	@Column(name = "cat_id")
	private int catId;
	
	public Item(int id, int orderId, int foodId, String foodName, double price, int unitQuanity, int catId) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.foodId = foodId;
		this.foodName = foodName;
		this.price = price;
		this.unitQuanity = unitQuanity;
		this.catId = catId;
	}

	
	
	@Override
	public String toString() {
		return "Item [id=" + id + ", orderId=" + orderId + ", foodId=" + foodId + ", foodName=" + foodName + ", price="
				+ price + ", unitQuanity=" + unitQuanity + ", catId=" + catId + "]";
	}



	public Item() {
		super();
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getFoodId() {
		return foodId;
	}

	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}

	public String getFoodName() {
		return foodName;
	}

	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getUnitQuanity() {
		return unitQuanity;
	}

	public void setUnitQuanity(int unitQuanity) {
		this.unitQuanity = unitQuanity;
	}

	public int getCatId() {
		return catId;
	}

	public void setCatId(int catId) {
		this.catId = catId;
	}
	
	
	
	

	
}
