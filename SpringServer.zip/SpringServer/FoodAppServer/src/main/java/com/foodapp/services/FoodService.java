package com.foodapp.services;

import java.util.List;

import com.foodapp.pojos.Food;

public interface FoodService {
	
	List<Food> findByFoodNameContaining(String name);
	//List<Food> findByCatId(int id);
	List<Food> findFoodAll();	
	Food findById(int id);
	Food addFood(Food food);
	
}
