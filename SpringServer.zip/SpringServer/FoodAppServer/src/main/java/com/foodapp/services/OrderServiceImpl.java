package com.foodapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foodapp.daos.OrderDao;
import com.foodapp.pojos.Order;

@Transactional
@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderDao dao;
	@Override
	public List<Order> findByUserId(int id) {	
		return dao.findByUserId(id) ;
	}

	@Override
	public List<Order> findById(int id) {
		return dao.findById(id);
	}

	@Override
	public List<Order> findAll() {
		return dao.findAll();
	}

}
