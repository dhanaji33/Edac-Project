package com.foodapp.services;

import java.util.List;

import com.foodapp.pojos.Order;

public interface OrderService {
	List<Order> findByUserId(int id);
	List<Order>  findById(int id);
	List<Order> findAll();
}
