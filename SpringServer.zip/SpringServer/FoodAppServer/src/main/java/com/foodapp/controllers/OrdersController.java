package com.foodapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foodapp.daos.ItemDao;
import com.foodapp.daos.OrderDao;
import com.foodapp.models.Response;
import com.foodapp.pojos.Item;
import com.foodapp.pojos.Order;
import com.foodapp.services.ItemService;
import com.foodapp.services.OrderService;

@CrossOrigin
@RestController
public class OrdersController {
	
	@Autowired
	private OrderService orderservice;
	@Autowired
	private OrderDao oDao;
	@SuppressWarnings("unused")
	@Autowired
	private ItemService itemService;
	@Autowired
	private ItemDao IDao;
	
	@PostMapping("/add-order")
	public ResponseEntity<?> AddOrder(Order ordr)
	{
		Order Order = oDao.save(ordr);
		if(Order!= null)
			return Response.success(Order);
		return Response.message("some error Occured");
	}
	
	@GetMapping("/all-orders")
	public ResponseEntity<?> ShowAllOrders(){
		List<Order> list = oDao.findAll();
		return Response.success(list);
	}
	
	@GetMapping("/orders/{id}")
	public ResponseEntity<?> FindOrderById(@PathVariable("id") int id){
		List<Order> orders = orderservice.findByUserId(id);
		return Response.success(orders);
	}
	
	
	@PostMapping("/add-item")
	public ResponseEntity<?> AddItem(Item item)
	{
		Item newItem = IDao.save(item);
		if(newItem!= null)
			return Response.success(newItem);
		return Response.message("some error Occured");
	}
	
	
	
	
	
	
}

