package com.foodapp.services;

import java.util.List;

import com.foodapp.pojos.Category;

public interface CategoryService {

	List<Category> findAll();
	Category findById(int id);
	
	
}
