package com.foodapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foodapp.daos.UserDao;
import com.foodapp.pojos.User;

@Transactional
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;
	
	
	@Override
	public User findByEmail(String email) {
		return dao.findByEmail(email);
	}

	@Override
	public User findById(int id) {
		User user = dao.findById(id);
		return user;
	}

	@Override
	public List<User> findAll() {
		return dao.findAll();
	}

	@Override
	public User authenticate(String email, String password) {
	 User user = dao.findByEmail(email);
	 if(user!= null && user.getPassword().equals(password)) {
		 	return user;
	 }
		return null;
	}

}
