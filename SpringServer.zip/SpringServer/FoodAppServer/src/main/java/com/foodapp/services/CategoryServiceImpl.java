package com.foodapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foodapp.daos.CategoryDao;
import com.foodapp.pojos.Category;
@Transactional
@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	private CategoryDao dao;
	
	
	@Override
	public List<Category> findAll() {
		return dao.findAll();
	}


	@Override
	public Category findById(int id) {
		return dao.findById(id);
	}


	
}
