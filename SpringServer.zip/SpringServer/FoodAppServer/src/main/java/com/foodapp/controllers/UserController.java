package com.foodapp.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foodapp.daos.UserDao;
import com.foodapp.models.Response;
import com.foodapp.pojos.User;
import com.foodapp.services.UserService;
@CrossOrigin
@RequestMapping("/user")
@RestController
public class UserController {

	@Autowired
	private UserDao userDao;
	@Autowired
	private UserService userService;
	
	@GetMapping("")
	public ResponseEntity<?> ShowAllUsers(){
		List<User> list = userDao.findAll();
		return Response.success(list);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> FindUserById(@PathVariable("id") int id){
		User user = userService.findById(id);
		return Response.success(user);
	}
	
	
	@PostMapping("/adduser")
	public ResponseEntity<?> AddUser(User user)
	{
		User newUser = userDao.save(user);
		if(newUser!= null)
			return Response.success(newUser);
		return Response.message("some error Occured");
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> DeleteUserById(@PathVariable("id") int id) 
	{
		User user = userService.findById(id);
		if(user!= null) {
			userDao.delete(user);
			return Response.message("successfully deleted User");
		}
		return Response.status(HttpStatus.NOT_FOUND);
	}
	
	@PutMapping("/update/{id}")
	public ResponseEntity<?> UpdateFoodById(@PathVariable("id") int id, User newUser) 
	{
	      User user = userService.findById(id);	
		if(user!= null) {
			 userDao.save(newUser);
			return Response.message("success");
		}
		return Response.status(HttpStatus.NOT_FOUND);
	}
	
	
	
	
}
