package com.foodapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foodapp.daos.EmployeeDao;
import com.foodapp.models.Response;
import com.foodapp.pojos.Employee;
import com.foodapp.services.EmployeeService;
@CrossOrigin
@RequestMapping("/emp")
@RestController
public class EmployeeController {
	@Autowired
	private EmployeeDao empDao;
	@Autowired
	private EmployeeService empService;
	
	
	@GetMapping("")
	public ResponseEntity<?> ShowAllEmployees(){
		List<Employee> list = empDao.findAll();
		return Response.success(list);
	}
	
	
	@GetMapping("/{id}")
	public ResponseEntity<?> FindEployeeById(@PathVariable("id") int id){
		Employee emp = empService.findById(id); 
		return Response.success(emp);
	}
	
	@PostMapping("/addemp")
	public ResponseEntity<?> AddUser(Employee emp)
	{
		Employee newemp = empDao.save(emp);
		if(newemp!= null)
			return Response.success(newemp);
		return Response.message("some error Occured");
	}
	
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<?> DeleteUserById(@PathVariable("id") int id) 
	{
		Employee emp = empDao.findById(id);
		if(emp!= null) {
			empDao.delete(emp);
			return Response.message("successfully deleted employee");
		}
		return Response.status(HttpStatus.NOT_FOUND);
	}
	
	
	@PutMapping("/update/{id}")
	public ResponseEntity<?> UpdateFoodById(@PathVariable("id") int id, Employee newEmp) 
	{
		Employee emp = empService.findById(id);
		if(emp!= null) {
			empDao.save(newEmp);
			return Response.message("success");
		}
		return Response.status(HttpStatus.NOT_FOUND);
	}
	
	
}
