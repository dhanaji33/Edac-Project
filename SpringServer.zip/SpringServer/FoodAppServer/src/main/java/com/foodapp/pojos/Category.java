package com.foodapp.pojos;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="categories")
public class Category {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "cat_id")
	@Id
	private int id;
	@Column(name = "cat_name")
	private String categoryName;
	
	@Column(name = "timestamp", insertable = false, updatable = false)
	@Temporal(TemporalType.DATE)
	private Date timeStamp;
	
	
	@OneToMany(mappedBy = "category", cascade = CascadeType.ALL)
	List<Food> foodlist;
	
	
	public List<Food> getFoodlist() {
		return foodlist;
	}


	public void setFoodlist(List<Food> foodlist) {
		this.foodlist = foodlist;
	}






	public Category() {
		
		
	}
	
	
	
	



	
	public Category(int id, String categoryName, Date timeStamp, List<Food> foodlist) {
		super();
		this.id = id;
		this.categoryName = categoryName;
		this.timeStamp = timeStamp;
		//this.foodlist = foodlist;
	}






	public int getId() {
		return id;
	}
	
	
	
	public void setId(int id) {
		this.id = id;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public Date getTimeStamp() {
		return timeStamp;
	}
	public void setTimeStamp(Date timeStamp) {
		this.timeStamp = timeStamp;
	}
	@Override
	public String toString() {
		return "Category [id=" + id + ", categoryName=" + categoryName + ", timeStamp=" + timeStamp + "]";
	}
	
	
	
	
	

	
	
	
}
