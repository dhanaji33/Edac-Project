package com.foodapp.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.foodapp.pojos.Item;

public interface ItemDao extends JpaRepository<Item, Integer>{

	List<Item> findByOrderId(int id);
	List<Item> findAll();
}
