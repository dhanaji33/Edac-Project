package com.foodapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foodapp.daos.FoodDao;
import com.foodapp.pojos.Food;
@Transactional
@Service
public class FoodServiceImpl implements FoodService {

	@Autowired
	private FoodDao dao;
	@Override
	public List<Food> findByFoodNameContaining(String name) {
		List<Food> list =  dao.findByFoodNameContaining(name);
		return list;
	}

//	@Override
//	public List<Food> findByCatId(int id) {
//	List<Food> list = dao.findByCatId(id);
//		return list;
//	}

	@Override
	public List<Food> findFoodAll() {
		List<Food> list = dao.findAll();
		return list;
	}

	@Override
	public Food findById(int id) {
		return dao.findById(id);
	}

	@Override
	public Food addFood(Food food) {
		Food newfood = dao.save(food);
		return newfood;
	}

	

}
