package com.foodapp.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foodapp.daos.ItemDao;
import com.foodapp.pojos.Item;

@Transactional
@Service
public class ItemServiceImpl implements ItemService  {

	@Autowired
	private ItemDao dao;
	@Override
	public List<Item> findByOrderId(int id) {
		return dao.findByOrderId(id);
	}
	@Override
	public List<Item> findAll() {
		List<Item> list= dao.findAll();
		return list;
	}

	

}
